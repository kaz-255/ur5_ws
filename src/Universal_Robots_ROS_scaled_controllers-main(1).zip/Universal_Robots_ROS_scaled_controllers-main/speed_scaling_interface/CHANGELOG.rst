^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package speed_scaling_interface
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2021-06-15)
------------------

0.1.0 (2021-06-10)
------------------
* Moved speed scaling interface to own package
* Contributors: Felix Exner
