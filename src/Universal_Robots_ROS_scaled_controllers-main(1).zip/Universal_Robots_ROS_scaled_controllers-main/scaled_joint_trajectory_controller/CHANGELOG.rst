^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package scaled_joint_trajectory_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2021-06-15)
------------------
* Require same CMake version in all packages
* Contributors: Felix Exner

0.1.0 (2021-06-10)
------------------
* Added metapackage
* Contributors: Felix Exner
