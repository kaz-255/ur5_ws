^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package scaled_controllers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2021-06-15)
------------------

0.1.0 (2021-06-10)
------------------
* Move out of ur_controllers package
* Contributors: Felix Exner
